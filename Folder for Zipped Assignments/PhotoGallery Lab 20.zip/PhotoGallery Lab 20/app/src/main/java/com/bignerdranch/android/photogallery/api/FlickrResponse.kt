package com.bignerdranch.android.photogallery.api

class FlickrResponse {
    lateinit var photos: PhotoResponse
}